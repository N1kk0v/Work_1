import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Num_2 {
    private JFrame frame;
    private JTextField rowsField;
    private JTextField colsField;
    private JTextArea outputArea;

    public Num_2() {
        createGUI();
    }

    private void createGUI() {
        frame = new JFrame("Матрицы");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Панель ввода размеров матрицы
        JPanel inputPanel = new JPanel(new GridLayout(2, 2));
        inputPanel.add(new JLabel("Количество строк (n):"));
        rowsField = new JTextField(5);
        inputPanel.add(rowsField);
        inputPanel.add(new JLabel("Количество столбцов (m):"));
        colsField = new JTextField(5);
        inputPanel.add(colsField);

        // Кнопка выполнения операций
        JButton executeButton = new JButton("Выполнить");
        executeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int n, m;
                try {
                    n = Integer.parseInt(rowsField.getText());
                    m = Integer.parseInt(colsField.getText());
                    if (n <= 0 || m <= 0) {
                        JOptionPane.showMessageDialog(frame, "Количество строк и столбцов должно быть положительным числом.");
                        return;
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Некорректный ввод. Пожалуйста, введите целое число.");
                    return;
                }

                // Создание матрицы с случайными целыми числами
                Random random = new Random();
                int[][] matrix = new int[n][m];
                for (int i = 0; i < n; i++) {
                    for (int j = 0; j < m; j++) {
                        matrix[i][j] = random.nextInt(100);
                    }
                }

                // Поиск максимального и минимального значения элементов матрицы
                int max = matrix [0][0];
                int min = matrix[0][0];
                for (int i = 0; i < n; i++) {
                    for (int j = 0; j < m; j++) {
                        if (matrix[i][j] > max) {
                            max = matrix[i][j];
                        }
                        if (matrix[i][j] < min) {
                            min = matrix[i][j];
                        }
                    }
                }

                // Вычисление суммы элементов для каждой строки и столбца
                int[] rowSums = new int[n];
                int[] colSums = new int[m];
                for (int i = 0; i < n; i++) {
                    for (int j = 0; j < m; j++) {
                        rowSums[i] += matrix[i][j];
                        colSums[j] += matrix[i][j];
                    }
                }

                // Вывод результатов
                StringBuilder output = new StringBuilder("Матрица:\n");
                for (int i = 0; i < n; i++) {
                    for (int j = 0; j < m; j++) {
                        output.append(matrix[i][j]).append(" ");
                    }
                    output.append("\n");
                }
                output.append("Максимальное значение: ").append(max).append("\n");
                output.append("Минимальное значение: ").append(min).append("\n");
                output.append("Суммы строк: ");
                for (int i = 0; i < n; i++) {
                    output.append(rowSums[i]).append(" ");
                }
                output.append("\n");
                output.append("Суммы столбцов: ");
                for (int i = 0; i < m; i++) {
                    output.append(colSums[i]).append(" ");
                }
                outputArea.setText(output.toString());
            }
        });

        // Панель вывода результатов
        outputArea = new JTextArea(20, 40);
        outputArea.setEditable(false);

        // Добавление компонентов в фрейм
        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(executeButton, BorderLayout.CENTER);
        frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Num_2();
            }
        });
    }
}

