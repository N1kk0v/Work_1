import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Num_6 extends JFrame {

    // Текстовые поля для ввода размера матриц и диапазона генерирования случайных значений
    private JTextField sizeField;
    private JTextField xField;
    private JTextField yField;

    public Num_6() {
        super("Умножение матриц");
        setLayout(new FlowLayout());

        // Метка и текстовое поле для ввода размера матриц
        JLabel sizeLabel = new JLabel("Введите размер матриц:");
        add(sizeLabel);
        sizeField = new JTextField(5);
        add(sizeField);

        // Метка и текстовое поле для ввода x
        JLabel xLabel = new JLabel("Введите x:");
        add(xLabel);
        xField = new JTextField(5);
        add(xField);

        // Метка и текстовое поле для ввода y
        JLabel yLabel = new JLabel("Введите y:");
        add(yLabel);
        yField = new JTextField(5);
        add(yField);

        // Кнопка для запуска расчета
        JButton calculateButton = new JButton("Рассчитать");
        add(calculateButton);

        // Обработчик события нажатия кнопки
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Чтение вводимых значений
                    int size = Integer.parseInt(sizeField.getText());
                    double x = Double.parseDouble(xField.getText());
                    double y = Double.parseDouble(yField.getText());

                    // Проверка корректности вводимых значений
                    if (size <= 0) {
                        JOptionPane.showMessageDialog(Num_6.this, "Размер матриц должен быть положительным целым числом.");
                        return;
                    }

                    if (x >= y) {
                        JOptionPane.showMessageDialog(Num_6.this, "x должен быть меньше y.");
                        return;
                    }

                    // Генерация матриц случайных чисел
                    double[][] matrix1 = generateMatrix(size, x, y);
                    double[][] matrix2 = generateMatrix(size, x, y);

                    // Умножение матриц
                    double[][] result = multiplyMatrices(matrix1, matrix2);

                    // Вывод результатов
                    String message = "Матрица 1:\n" + printMatrix(matrix1) +
                            "\nМатрица 2:\n" + printMatrix(matrix2) +
                            "\nРезультат:\n" + printMatrix(result);

                    JOptionPane.showMessageDialog(Num_6.this, message);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(Num_6.this, "Неверный формат ввода. Пожалуйста, введите корректные числа.");
                }
            }
        });

        setSize(300, 150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    // Генерация матрицы случайных чисел
    private double[][] generateMatrix(int size, double x, double y) {
        double[][] matrix = new double[size][size];
        Random random = new Random();

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                matrix[i][j] = x + (y - x) * random.nextDouble();
            }
        }

        return matrix;
    }

    // Умножение матриц
    private double[][] multiplyMatrices(double[][] matrix1, double[][] matrix2) {
        int size = matrix1.length;
        double[][] result = new double[size][size];

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                for (int k = 0; k < size; k++) {
                    result[i][j] += matrix1[i][k] * matrix2[k][j];
                }
            }
        }

        return result;
    }

    // Вывод матрицы в строковом формате
    private String printMatrix(double[][] matrix) {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                sb.append(String.format("%10.2f", matrix[i][j]));
            }
            sb.append("\n");
        }

        return sb.toString();
    }

    public static void main(String[] args) {
        new Num_6();
    }
}