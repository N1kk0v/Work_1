import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Random;

public class Num_1 {
    // Создание окна
    public static void main(String[] args) {
        JFrame frame = new JFrame("Массив случайных чисел");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTextField inputFieldN = new JTextField(5);
        JTextField inputFieldX = new JTextField(5);
        JButton generateButton = new JButton("Сгенерировать!");
        JTextArea outputField = new JTextArea(10, 20);

        JPanel panel = new JPanel();
        panel.add(new JLabel("Введите длину массива: "));
        panel.add(inputFieldN);
        panel.add(new JLabel("Введите порог: "));
        panel.add(inputFieldX);
        panel.add(generateButton);

        generateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int n = Integer.parseInt(inputFieldN.getText());
                    int x = Integer.parseInt(inputFieldX.getText());
                    if (n <= 0 || x < 0) {
                        throw new NumberFormatException();
                    }
                    int[] arr = generateRandomArray(n);
                    outputField.setText("Массив: " + Arrays.toString(arr) + "\n");
                    findIndicesGreaterThanX(arr, x, outputField);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Неверный ввод!");
                }
            }
        });

        panel.add(new JScrollPane(outputField));
        frame.add(panel);
        frame.setVisible(true);
    }

    public static int[] generateRandomArray(int n) {
        int[] arr = new int[n];
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            arr[i] = random.nextInt(100);
        }
        return arr;
    }

    public static void findIndicesGreaterThanX(int[] arr, int x, JTextArea outputField) {
        StringBuilder result = new StringBuilder();
        result.append("Индексы элементов, превышающих порог ").append(x).append(":\n");
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > x) {
                result.append(i).append(" ");
            }
        }
        outputField.append(result.toString());
    }
}