import javax.swing.JOptionPane;

public class Num_3 {
    public static void main(String[] args) {
        // Размер массива
        String input = JOptionPane.showInputDialog("Введите размер массива:");
        int n;
        try {
            n = Integer.parseInt(input);
            if (n <= 0) {
                throw new Exception("Размер массива должен быть положительным числом");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ошибка: " + e.getMessage());
            return;
        }

        // Создание массива
        int[] array = new int[n];
        for (int i = 0; i < n; i++) {
            array[i] = (int) (Math.random() * 100);
        }

        // Оригинал
        StringBuilder originalArrayString = new StringBuilder("Оригинальный массив:\n");
        for (int i = 0; i < n; i++) {
            originalArrayString.append(array[i]).append(" ");
        }
        JOptionPane.showMessageDialog(null, originalArrayString.toString());

        // Реверс
        int[] reversedArray = new int[n];
        for (int i = 0; i < n; i++) {
            reversedArray[n - i - 1] = array[i];
        }

        // Вывод
        StringBuilder reversedArrayString = new StringBuilder("Реверсированный массив:\n");
        for (int i = 0; i < n; i++) {
            reversedArrayString.append(reversedArray[i]).append(" ");
        }
        JOptionPane.showMessageDialog(null, reversedArrayString.toString());
    }
}