import java.util.Random;
import java.util.Scanner;

public class Num_8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        System.out.println("Введите нижнюю границу диапазона:");
        int lowerBound = scanner.nextInt();

        System.out.println("Введите верхнюю границу диапазона:");
        int upperBound = scanner.nextInt();

        int numberToGuess = random.nextInt(upperBound - lowerBound + 1) + lowerBound;

        while (true) {
            System.out.println("Угадайте число:");
            String input = scanner.next();

            if (input.equalsIgnoreCase("Сдаюсь")) {
                System.out.println("Вы сдались. Загаданное число было " + numberToGuess);
                break;
            }

            int guess = Integer.parseInt(input);

            if (guess < numberToGuess) {
                System.out.println("Загаданное число больше вашего.");
            } else if (guess > numberToGuess) {
                System.out.println("Загаданное число меньше вашего.");
            } else {
                System.out.println("Вы угадали загаданное число!");
                break;
            }
        }
    }
}