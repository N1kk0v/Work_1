import javax.swing.JOptionPane;

public class Num_7 {
    public static void main(String[] args) {
        // Получаем выбор цели расчета от пользователя
        String goal = JOptionPane.showInputDialog(null,
                "Выберите цель расчета:\n1 - Площадь\n2 - Длина",
                "Калькулятор окружности",
                JOptionPane.INFORMATION_MESSAGE);

        int goalChoice;
        try {
            goalChoice = Integer.parseInt(goal);
            if (goalChoice != 1 && goalChoice != 2) {
                throw new Exception("Неверный выбор цели расчета");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "Неверный выбор цели расчета. Пожалуйста, введите 1 или 2.",
                    "Ошибка",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Получаем радиус от пользователя
        String radiusInput = JOptionPane.showInputDialog(null,
                "Введите радиус окружности:",
                "Калькулятор окружности",
                JOptionPane.INFORMATION_MESSAGE);

        double radius;
        try {
            radius = Double.parseDouble(radiusInput);
            if (radius <= 0) {
                throw new Exception("Радиус должен быть положительным числом");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "Неверный ввод радиуса. Пожалуйста, введите положительное число.",
                    "Ошибка",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Вычисляем значение в зависимости от цели расчета
        double result;
        if (goalChoice == 1) {
            result = calculateArea(radius);
            JOptionPane.showMessageDialog(null,
                    "Площадь окружности: " + result,
                    "Результат",
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            result = calculateCircumference(radius);
            JOptionPane.showMessageDialog(null,
                    "Длина окружности: " + result,
                    "Результат",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // Метод для вычисления площади окружности
    public static double calculateArea(double radius) {
        return Math.PI * (radius * radius);
    }

    // Метод для вычисления длины окружности
    public static double calculateCircumference(double radius) {
        return 2 * Math.PI * radius;
    }
}