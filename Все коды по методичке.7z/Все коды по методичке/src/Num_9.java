import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Locale;

public class Num_9 {
    private JFrame mainFrame;
    private JFrame calendarFrame;

    // Создаем основное окно программы
    public Num_9() {
        createMainFrame();
    }

    // Создаем панель ввода месяца и года
    private void createMainFrame() {
        mainFrame = new JFrame("Календарь");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(300, 100);

        // Создаем панель для ввода месяца и года
        JPanel panel = new JPanel();
        panel.add(new JLabel("Месяц:"));
        JTextField monthField = new JTextField(5);
        panel.add(monthField);

        panel.add(new JLabel("Год:"));
        JTextField yearField = new JTextField(5);
        panel.add(yearField);

        // Создаем кнопку для генерации календаря
        JButton generateButton = new JButton("Сгенерировать календарь");
        generateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Обрабатываем ввод месяца и года
                String monthStr = monthField.getText();
                int year = Integer.parseInt(yearField.getText());

                int month;
                if (monthStr.matches("\\d+")) {
                    month = Integer.parseInt(monthStr);
                } else {
                    month = getMonthFromName(monthStr);
                }

                // Генерируем календарь
                generateCalendar(month, year);
            }
        });
        panel.add(generateButton);

        mainFrame.add(panel, BorderLayout.CENTER);
        mainFrame.setVisible(true);
    }

    // Конвертируем строку месяца в числовое значение
    private int getMonthFromName(String monthName) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM", Locale.forLanguageTag("ru"));
        for (int i = 1; i <= 12; i++) {
            if (formatter.format(LocalDate.of(2022, i, 1)).equals(monthName)) {
                return i;
            }
        }
        return -1;
    }

    // Генерируем календарь для заданного месяца и года
    private void generateCalendar(int month, int year) {
        mainFrame.setVisible(false);
        calendarFrame = new JFrame("Календарь " + getMonthName(month) + " " + year);
        calendarFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        calendarFrame.setSize(400, 300);

        LocalDate date = LocalDate.of(year, month, 1);
        int daysInMonth = date.lengthOfMonth();
        int firstDayOfWeek = date.getDayOfWeek().getValue();

        // Создаем панель для вывода календаря
        JPanel panel = new JPanel(new GridLayout(0, 7));
        for (int i = 1; i < firstDayOfWeek; i++) {
            panel.add(new JLabel(" "));
        }
        for (int i = 1; i <= daysInMonth; i++) {
            JLabel dayLabel = new JLabel(String.valueOf(i));
            dayLabel.setHorizontalAlignment(JLabel.CENTER);
            panel.add(dayLabel);
        }
        calendarFrame.add(panel, BorderLayout.CENTER);

        calendarFrame.setVisible(true);
    }

    // Возвращаем полное имя месяца
    private String getMonthName(int month) {
        return LocalDate.of(2022, month, 1).getMonth().getDisplayName(TextStyle.FULL, Locale.forLanguageTag("ru"));
    }

    public static void main(String[] args) {
        new Num_9();
    }
}