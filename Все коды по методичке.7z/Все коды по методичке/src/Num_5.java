import javax.swing.JOptionPane;

public class Num_5 {
    public static void main(String[] args) {
        // Получаем размер массива от пользователя
        String input = JOptionPane.showInputDialog("Введите размер массива:");
        int n;
        try {
            n = Integer.parseInt(input);
            if (n <= 0) {
                throw new Exception("Размер массива должен быть положительным числом");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ошибка: " + e.getMessage());
            return;
        }

        // Получаем диапазон генерирования случайных значений от пользователя
        input = JOptionPane.showInputDialog("Введите нижнюю границу диапазона (±x):");
        double x;
        try {
            x = Double.parseDouble(input);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ошибка: " + e.getMessage());
            return;
        }

        input = JOptionPane.showInputDialog("Введите верхнюю границу диапазона (±y):");
        double y;
        try {
            y = Double.parseDouble(input);
            if (x > y) {
                throw new Exception("Нижняя граница должна быть меньше верхней");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ошибка: " + e.getMessage());
            return;
        }

        // Создаем два массива случайных чисел
        double[] array1 = new double[n];
        double[] array2 = new double[n];
        for (int i = 0; i < n; i++) {
            array1[i] = x + (Math.random() * (y - x)); // случайное число в диапазоне от x до y
            array2[i] = x + (Math.random() * (y - x)); // случайное число в диапазоне от x до y
        }

        // Создаем массив для суммы попарных элементов
        double[] sumArray = new double[n];
        for (int i = 0; i < n; i++) {
            sumArray[i] = array1[i] + array2[i];
        }

        // Выводим результаты
        StringBuilder result = new StringBuilder("Результаты:\n");
        result.append("Массив 1: ").append(java.util.Arrays.toString(array1)).append("\n");
        result.append("Массив 2: ").append(java.util.Arrays.toString(array2)).append("\n");
        result.append("Сумма попарных элементов: ").append(java.util.Arrays.toString(sumArray)).append("\n");
        JOptionPane.showMessageDialog(null, result.toString());
    }
}